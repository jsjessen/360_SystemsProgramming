#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

struct partition
{
	unsigned char drive;            /* 0x80 - active */

	unsigned char head;             /* starting head */
	unsigned char sector;           /* starting sector */
	unsigned char cylinder;         /* starting cylinder */

	unsigned char sys_type;         /* partition type, 5 = EXT */

	unsigned char end_head;         /* end head */
	unsigned char end_sector;       /* end sector */
	unsigned char end_cylinder;     /* end cylinder */

	unsigned long start_sector;     /* starting sector counting from 0 */
	unsigned long nr_sectors;       /* nr of sectors in partition */
};

void print_raw(struct partition *part, int partition_number)
{
	/*  The cylinder value is actually 10 bits. 
	 *  The highest 2 bits of cylinder value are in 
	 *  the leftmost 2 bits of sector, which is only 6 bits.
	 */
	// Sector:   |_|_|_|_|_|_|_|_|	
	//               |-----------|
	//         &  0 0 1 1 1 1 1 1     Use bit masking
	//           |-------|-------|	
	//		 3	 F

	int start_sect = part->sector & 0x3F;
	int end_sect = part->end_sector & 0x3F;	

	//             From Sector
	// Cylinder:    | v | v |_|_|_|_|_|_|_|_|	2 + 8 = 10 bytes

	int start_cyl = ((part->sector >> 6) << 8) + part->cylinder;
	int end_cyl = ((part->end_sector >> 6) << 8) + part->end_cylinder;

	printf("%2X", part->drive);
	printf("%4X", part->head);
	printf("%4d", start_sect);
	printf("%4d", start_cyl);
	printf("%4X", part->sys_type);
	printf("%4X", part->end_head);
	printf("%4d", end_sect);
	printf("%4d", end_cyl + 1);
	printf("%6lu", part->start_sector);
	printf("%6lu", part->nr_sectors);
	printf("\n");
}

void print_fdisk(struct partition *part, int partition_number)
{
	int start_cyl = ((part->sector >> 6) << 8) + part->cylinder + 1;
	int end_cyl = ((part->end_sector >> 6) << 8) + part->end_cylinder + 1;

	printf("%5d", start_cyl);
	printf("%10d", end_cyl);
	printf("%10lu", part->nr_sectors / 2);
	printf("%6X", part->sys_type);
	printf("\n");
}

int main()
{
	int i = 1, nr = 0, pos = -1;
	int fd = 0;
	char  buf[512] ;
	struct partition *sp;
	int ret = 0;

	if ((fd = open("vdisk", O_RDONLY)) == -1)
	{
		perror("Open");
		exit(1);
	}

	if ((nr = read(fd, buf, sizeof(buf))) == -1)
	{
		perror("Read");
		exit(1);
	}

	if (ret = close(fd) == -1)
	{
		perror("Close");
		exit(1);
	}

	printf("---------------- RAW Form ----------------\n");
	for (i = 0 ; i < 4 ; i++)
	{
		sp = (struct partition *)(buf + 0x1BE + (16 * i));
		print_raw(sp, i);
	}

	printf("------------ Linux fdisk Form -----------\n");
	printf("start_cyl  end_cyl  blocks  type\n");
	for (i = 0 ; i < 4 ; i++)
	{
		sp = (struct partition *)(buf + 0x1BE + (16 * i));
		print_fdisk(sp, i);

		/*
		   If a partition is EXTEND type (type=5), the partition may be further divided 
		   into more partitions. The extended partitions forms a link-list. 

		   Assume P4 is EXT type:
		   P4's beginSector = MBR
		   P5's beginSector
		   P6's MBR's sector# = MBR
		   (r.e. to P4)     P6's begin sector#
		   P7's MBR r.e. to P4 --> etc.

		   In the extended partitions, all the sector numbers are RELATIVE to the 
		   beginSector of the extend partition.

		   The first sector of each extended partition is a local MBR. Each local MBR also
		   has a partition table at the offset 0x1BE. It contains only 2 entries. The first
		   entry defines that extended partition, and the second entry points to the MBR of
		   the next extended partition. As usual, the link list ends with a 0 pointer.
		   */ 
		if (sp->sys_type == 5)
		{
			printf("****** Look for Extend Partition ******\n");

		}

	}

	return 0;
}
